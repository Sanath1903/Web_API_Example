﻿using CoreApi.Data.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CoreApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly APIDbContext _context;

        public EmployeeController(APIDbContext context)
        {
            _context = context;
        }

        /* [HttpGet]
          public async Task<Employee> Get()
          {
              return await _context.Employees.ToListAsync();
          }

          [HttpGet("{id}")]
          public async Task Get(int id)
          {
              var Employee = await _context.Employees.FirstOrDefaultAsync(m => m.Id == id);
              if (Employee == null)
                  return NotFound();
              return Ok(Employee);

          }

          [HttpPost]
          public async Task Post(Employee employee)
          {
              _context.Add(employee);
              await _context.SaveChangesAsync();
              return Ok();
          }
          [HttpPut]
          public async Task Put(Employee employeeData)
          {
              if (employeeData == null || employeeData.Id == 0)
                  return BadRequest();

              var employee = await _context.Employees.FindAsync(employeeData.Id);
              if (employee == null)
                  return NotFound();
              employee.FirstName = employeeData.FirstName;
              employee.LastName = employeeData.LastName;
              employee.Email = employeeData.Email;
              employee.DOB = employeeData.DOB;
              employee.DepartmentId = employeeData.DepartmentID;
              await _context.SaveChangesAsync();
              return Ok();
          }
          [HttpDelete("{id}")]
          public async Task <Employee>Delete(int id)
          {
              var employee = await _context.Employees.FindAsync(id);
              if (employee == null) return NotFound();
              _context.Employees.Remove(employee);
              await _context.SaveChangesAsync();
              return Ok();

          }


      }*/
    }
}
   