﻿using CoreApi.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace CoreApi.Data.Models
{
    public class APIDbContext : DbContext
    {
        public APIDbContext(DbContextOptions<APIDbContext> options) : base(options) { }
        public DbSet<Department> Departments
        {
            get;
            set;
        }
        public DbSet<Employee> Employees
        {
            get;
            set;
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Employee>().ToTable("Employee").HasKey();
            builder.Entity<Department>().ToTable("Department").HasKey();

        }
    }
}